import React from "react"
import {Admin, Resource,fetchUtils } from "react-admin"
import restProvider from "ra-data-simple-rest"
import AppointmentList from './components/AppointmentList'
import AppointmentCreate from './components/AppointmentCreate'
import AppointmentEdit from './components/AppointmentEdit'
import AppointmentCalendar from './components/AppointmentCalendar'

function App() {
  const fetchJson = (url, options = {}) => {
    if (!options.headers) {
        options.headers = new Headers({ Accept: 'application/json' });
    }
    // add your own headers here
    options.headers.set('X-Custom-Header', 'foobar');
    return fetchUtils.fetchJson(url, options);
}
const dataProvider = restProvider('http://localhost:3000', fetchJson);

  return <Admin dataProvider={dataProvider}>
    <Resource name="appointments" list={AppointmentList} create={AppointmentCreate} edit={AppointmentEdit}/>
    <Resource name="Calender" list={ AppointmentCalendar} />
   
     
  </Admin>
}

export default App;
