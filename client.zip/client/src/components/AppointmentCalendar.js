import React, { FC, useState } from 'react';
import { Inject, ScheduleComponent, Day, Week, WorkWeek, Month, Agenda } from '@syncfusion/ej2-react-schedule'
import { useFetch } from "../hooks";
import { DataManager, WebApiAdaptor } from '@syncfusion/ej2-data';

const AppointmentCalendar = (props) =>{

    const [data, loading] =  useFetch("http://localhost:5000/appointments");
    console.log(data)
    return (
        <ScheduleComponent  eventSettings={{ dataSource: data[0]}}>
            <Inject services={[Day, Week, WorkWeek, Month, Agenda]} />
        </ScheduleComponent>
        
    )
}

export default AppointmentCalendar
