import { TextField } from "@material-ui/core"
import React from "react"
import {Edit, SimpleForm, TextInput, DateTimeInput  } from "react-admin"

const AppointmentEdit = (props) =>{
    return (
        <Edit title="Edit the Appointment" {...props}>
            <SimpleForm>
                <TextInput disabled source="id"/>   
                <TextInput source="Subject"/>
                <TextInput multiline source="description"/>
                <DateTimeInput  label="StartTime" source="StartTime"/>
                <DateTimeInput  label="EndTime" source="EndTime"/>
                <DateTimeInput label="createdAt" source="createdAt"/>
            </SimpleForm>
        </Edit>
    )
}

export default AppointmentEdit