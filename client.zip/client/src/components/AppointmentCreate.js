import { TextField } from "@material-ui/core"
import React from "react"
import {Create, SimpleForm, TextInput, DateTimeInput  } from "react-admin"

/* Appointment create */
const AppointmentCreate = (props) =>{
    return (
        <Create title="Create the Appointment" {...props}>
            <SimpleForm>
                <TextInput source="Subject"/>
                <TextInput multiline source="description"/>
                <DateTimeInput  label="StartTime" source="StartTime"/>
                <DateTimeInput  label="EndTime" source="EndTime"/>
                <DateTimeInput label="createdAt" source="createdAt"/>
            </SimpleForm>
        </Create>
    )
}

export default AppointmentCreate