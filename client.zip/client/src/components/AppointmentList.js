import React from 'react'
import {
    List, 
    Datagrid, 
    TextField, 
    EditButton,
    DateField,
    BooleanInput,
    DeleteButton,
    TextInput,
    Filter, ReferenceInput, SelectInput
} from 'react-admin'

/* List of all Appointments */
const AppointmentList =(props) =>{
    return <List {...props} >
        <Datagrid>
            <TextField source="id"/>
            <TextField source="Subject"/>
            <TextField source="description"/>
            <DateField  source="StartTime"/>
            <DateField  source="EndTime"/>
            <DateField source="createdAt"/>
            <EditButton basePath='/appointments'/>
            <DeleteButton basePath='/appointments'/>
        </Datagrid>

    </List>
} 

export default AppointmentList;